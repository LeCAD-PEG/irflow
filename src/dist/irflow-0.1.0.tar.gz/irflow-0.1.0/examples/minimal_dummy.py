# examples/minimal_dummy_flt.py
from pathlib import Path

from irflow.core.flow import IRFlow
from irflow.core.registry import BackendRegistry
from irflow.core.executor import LocalExecutor
from irflow.steps.field_line_tracing import FieldLineTracing
from irflow.models.flt_config import FieldLineTracingConfig
from irflow.backends.field_line_tracing.dummy import DummyFLTBackend


def main():
    registry = BackendRegistry()
    registry.register("flt", "Dummy", DummyFLTBackend)

    flow = IRFlow(
        case_name="dummy_case_001",
        root_dir=Path("./runs"),
        executor=LocalExecutor(),
        registry=registry,
        metadata={"purpose": "dummy FLT test"},
    )

    flt = FieldLineTracing(
        config=FieldLineTracingConfig(
            backend="Dummy",
            surface_mesh="does_not_matter_yet.vtk",
        )
    )

    flow.add_step(flt)
    result = flow.run()

    print("Case dir:", result.case_dir)
    print("Exchange:", result.step_results[-1].exchange_h5_path)


if __name__ == "__main__":
    main()
